require("dotenv").config();

const express = require("express");

const cors = require("cors");

const connectDB = require("./config/db");

const authRoutes = require("./routes/authRoutes");

const organizationRoutes = require("./routes/organizationRoutes");

const featureRoutes = require("./routes/featureRoutes");

const superAdminRoutes = require("./routes/superAdminRoutes");

const publicRoutes = require("./routes/publicRoutes");

const app = express();

connectDB();

app.use(cors());

app.use(express.json());

app.use("/api/super-admin", superAdminRoutes);

app.use("/api/auth", authRoutes);

app.use("/api/organizations", organizationRoutes);

app.use("/api/features", featureRoutes);

app.use("/api/public", publicRoutes);

app.get("/", (req, res) => {
  res.send("API Running");
});

app.listen(process.env.PORT, () => {
  console.log(`Server running on port ${process.env.PORT}`);
});
