const jwt = require("jsonwebtoken");

exports.superAdminLogin = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (
      email === process.env.SUPER_ADMIN_EMAIL &&
      password === process.env.SUPER_ADMIN_PASSWORD
    ) {
      const token = jwt.sign(
        {
          role: "SUPER_ADMIN",
        },
        process.env.JWT_SECRET,
        {
          expiresIn: "1d",
        },
      );

      return res.json({
        token,
        role: "SUPER_ADMIN",
      });
    }

    return res.status(401).json({
      message: "Invalid credentials",
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};
