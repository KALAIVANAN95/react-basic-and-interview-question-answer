const FeatureFlag = require("../models/FeatureFlag");
const Organization = require("../models/Organization");

exports.createFeature = async (req, res) => {
  try {
    const { featureKey, enabled } = req.body;

    const feature = await FeatureFlag.create({
      featureKey,
      enabled,
      organizationId:
        req.user.organizationId,
    });

    res.status(201).json(feature);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

exports.getFeatures = async (req, res) => {
  try {
    const features = await FeatureFlag.find({
      organizationId:
        req.user.organizationId,
    });

    res.json(features);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

exports.updateFeature = async (req, res) => {
  try {
    const feature = await FeatureFlag.findById(
      req.params.id
    );

    if (!feature) {
      return res.status(404).json({
        message: "Feature not found",
      });
    }

    feature.featureKey =
      req.body.featureKey;

    feature.enabled = req.body.enabled;

    await feature.save();

    res.json(feature);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

exports.deleteFeature = async (req, res) => {
  try {
    await FeatureFlag.findByIdAndDelete(
      req.params.id
    );

    res.json({
      message: "Feature deleted",
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

exports.checkFeature = async (req, res) => {
  try {
    const {
      organizationName,
      featureKey,
    } = req.body;

    const organization =
      await Organization.findOne({
        name: organizationName,
      });

    if (!organization) {
      return res.status(404).json({
        message: "Organization not found",
      });
    }

    const feature =
      await FeatureFlag.findOne({
        organizationId:
          organization._id,
        featureKey,
      });

    res.json({
      enabled: feature
        ? feature.enabled
        : false,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};