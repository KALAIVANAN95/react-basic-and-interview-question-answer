const Organization = require("../models/Organization");

exports.createOrganization = async (req, res) => {
  try {
    const { name } = req.body;

    const existing = await Organization.findOne({
      name,
    });

    if (existing) {
      return res.status(400).json({
        message: "Organization already exists",
      });
    }

    const organization = await Organization.create({
      name,
    });

    res.status(201).json(organization);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

exports.getOrganizations = async (req, res) => {
  try {
    const organizations = await Organization.find();

    res.json(organizations);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};
