const express = require("express");

const router = express.Router();

const {
  createFeature,
  getFeatures,
  updateFeature,
  deleteFeature,
  checkFeature,
} = require("../controllers/featureController");

const authMiddleware = require("../middleware/authMiddleware");

const roleMiddleware = require("../middleware/roleMiddleware");

router.post(
  "/",
  authMiddleware,
  roleMiddleware("ORG_ADMIN"),
  createFeature
);

router.get(
  "/",
  authMiddleware,
  roleMiddleware("ORG_ADMIN"),
  getFeatures
);

router.put(
  "/:id",
  authMiddleware,
  roleMiddleware("ORG_ADMIN"),
  updateFeature
);

router.delete(
  "/:id",
  authMiddleware,
  roleMiddleware("ORG_ADMIN"),
  deleteFeature
);

router.post("/check", checkFeature);

module.exports = router;