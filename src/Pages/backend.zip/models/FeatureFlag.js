const mongoose = require("mongoose");

const featureFlagSchema = new mongoose.Schema(
  {
    featureKey: {
      type: String,
      required: true,
    },

    enabled: {
      type: Boolean,
      default: false,
    },

    organizationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Organization",
      required: true,
    },
  },
  {
    timestamps: true,
  },
);

// Ensure unique featureKey per organization
featureFlagSchema.index({ featureKey: 1, organizationId: 1 }, { unique: true });

module.exports = mongoose.model("FeatureFlag", featureFlagSchema);
