import {
  Button,
  Container,
  List,
  ListItem,
  TextField,
  Typography,
  Paper,
} from "@mui/material";

import { useEffect, useState } from "react";

import API from "../api/axios";

function Dashboard() {
  const [name, setName] = useState("");

  const [organizations, setOrganizations] = useState([]);

  const [loading, setLoading] = useState(false);

  const token = localStorage.getItem("token");

  const handleLogout = () => {
    localStorage.removeItem("token");

    window.location.href = "/";
  };

  const fetchOrganizations = async () => {
    try {
      const res = await API.get("/organizations", {
        headers: {
          authorization: `Bearer ${token}`,
        },
      });

      setOrganizations(res.data);
    } catch (error) {
      alert(error.response?.data?.message || "Failed to fetch organizations");
    }
  };

  useEffect(() => {
    if (!token) {
      window.location.href = "/";
      return;
    }

    fetchOrganizations();
  }, []);

  const createOrganization = async () => {
    try {
      if (!name) {
        return alert("Please enter organization name");
      }

      setLoading(true);

      await API.post(
        "/organizations",
        { name },
        {
          headers: {
            authorization: `Bearer ${token}`,
          },
        },
      );

      setName("");

      fetchOrganizations();
    } catch (error) {
      alert(error.response?.data?.message || "Organization creation failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="md">
      <Paper
        sx={{
          p: 4,
          mt: 5,
          borderRadius: 3,
        }}
      >
        <Button
          variant="outlined"
          color="secondary"
          sx={{
            float: "right",
            mb: 2,
          }}
          onClick={handleLogout}
        >
          Logout
        </Button>

        <Typography variant="h4" mb={3}>
          Organizations
        </Typography>

        <TextField
          fullWidth
          label="Organization Name"
          margin="normal"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <Button
          variant="contained"
          sx={{ mt: 2 }}
          onClick={createOrganization}
          disabled={loading}
        >
          {loading ? "Creating..." : "Create"}
        </Button>

        <List sx={{ mt: 3 }}>
          {organizations.map((org) => (
            <ListItem key={org._id}>{org.name}</ListItem>
          ))}
        </List>
      </Paper>
    </Container>
  );
}

export default Dashboard;
