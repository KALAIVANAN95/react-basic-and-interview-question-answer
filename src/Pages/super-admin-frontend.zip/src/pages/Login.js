import { Button, Container, Paper, TextField, Typography } from "@mui/material";

import { useState } from "react";

import API from "../api/axios";

function Login() {
  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const handleLogin = async () => {
    try {
      const res = await API.post("/super-admin/login", form);

      localStorage.setItem("token", res.data.token);

      window.location.href = "/dashboard";
    } catch (error) {
      alert("Login Failed");
    }
  };

  return (
    <Container maxWidth="sm">
      <Typography
        variant="h3"
        align="center"
        sx={{ mt: 6, mb: 4, fontWeight: 700, letterSpacing: 1 }}
      >
        SaaS-style Feature Flag Management System
      </Typography>
      <Paper sx={{ p: 4, mt: 2 }}>
        <Typography variant="h4" mb={3} align="center">
          Super Admin Login
        </Typography>

        <TextField
          fullWidth
          margin="normal"
          label="Email"
          onChange={(e) =>
            setForm({
              ...form,
              email: e.target.value,
            })
          }
        />

        <TextField
          fullWidth
          margin="normal"
          label="Password"
          type="password"
          onChange={(e) =>
            setForm({
              ...form,
              password: e.target.value,
            })
          }
        />

        <Button
          fullWidth
          variant="contained"
          sx={{ mt: 2 }}
          onClick={handleLogin}
        >
          Login
        </Button>
      </Paper>
    </Container>
  );
}

export default Login;
