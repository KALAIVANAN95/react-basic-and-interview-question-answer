import {
  Button,
  Container,
  Paper,
  TextField,
  Typography,
  Box,
} from "@mui/material";

import { useState } from "react";

import axios from "axios";

function App() {
  const [organizationName, setOrganizationName] = useState("");
  const [featureKey, setFeatureKey] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const checkFeature = async () => {
    try {
      setLoading(true);
      setResult("");
      const res = await axios.post("http://localhost:5000/api/features/check", {
        organizationName,
        featureKey,
      });
      setResult(
        res.data.enabled ? "✅ Feature Enabled" : "❌ Feature Disabled",
      );
    } catch (error) {
      setResult(error.response?.data?.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setOrganizationName("");
    setFeatureKey("");
    setResult("");
  };

  return (
    <Container maxWidth="sm">
      <Paper
        elevation={3}
        sx={{
          p: 4,
          mt: 10,
          borderRadius: 3,
        }}
      >
        <Typography variant="h4" textAlign="center" mb={3}>
          Feature Flag Checker
        </Typography>

        <TextField
          fullWidth
          label="Organization Name"
          margin="normal"
          value={organizationName}
          onChange={(e) => setOrganizationName(e.target.value)}
        />

        <TextField
          fullWidth
          label="Feature Key"
          margin="normal"
          value={featureKey}
          onChange={(e) => setFeatureKey(e.target.value)}
        />

        <Button
          fullWidth
          variant="contained"
          sx={{ mt: 3 }}
          onClick={checkFeature}
          disabled={loading}
        >
          {loading ? "Checking..." : "Check Feature"}
        </Button>
        <Button
          fullWidth
          variant="outlined"
          sx={{ mt: 1 }}
          onClick={handleReset}
          disabled={loading}
        >
          Reset
        </Button>

        {result && (
          <Box mt={3}>
            <Typography variant="h6" textAlign="center">
              {result}
            </Typography>
          </Box>
        )}
      </Paper>
    </Container>
  );
}

export default App;
