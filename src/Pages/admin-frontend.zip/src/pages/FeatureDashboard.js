import {
  Button,
  Checkbox,
  Container,
  FormControlLabel,
  List,
  ListItem,
  Paper,
  TextField,
  Typography,
  Box,
} from "@mui/material";

import { useEffect, useState } from "react";

import API from "../api/axios";

function FeatureDashboard() {
  const [featureKey, setFeatureKey] = useState("");
  const [enabled, setEnabled] = useState(false);
  const [features, setFeatures] = useState([]);
  const [editId, setEditId] = useState(null);

  const token = localStorage.getItem("token");

  const fetchFeatures = async () => {
    const res = await API.get("/features", {
      headers: {
        authorization: `Bearer ${token}`,
      },
    });
    setFeatures(res.data);
  };

  useEffect(() => {
    fetchFeatures();
  }, []);

  const createOrUpdateFeature = async () => {
    if (editId) {
      // Update existing feature
      await API.put(
        `/features/${editId}`,
        { featureKey, enabled },
        {
          headers: { authorization: `Bearer ${token}` },
        },
      );
    } else {
      // Create new feature
      await API.post(
        "/features",
        { featureKey, enabled },
        {
          headers: { authorization: `Bearer ${token}` },
        },
      );
    }
    setFeatureKey("");
    setEnabled(false);
    setEditId(null);
    fetchFeatures();
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    window.location.href = "/";
  };
  const startEdit = (feature) => {
    setFeatureKey(feature.featureKey);
    setEnabled(feature.enabled);
    setEditId(feature._id);
  };

  const deleteFeature = async (id) => {
    await API.delete(`/features/${id}`, {
      headers: {
        authorization: `Bearer ${token}`,
      },
    });

    fetchFeatures();
  };

  return (
    <Container maxWidth="md">
      <Paper sx={{ p: 4, mt: 5 }}>
        <Button
          variant="outlined"
          color="secondary"
          sx={{ float: "right", mb: 2 }}
          onClick={handleLogout}
        >
          Logout
        </Button>
        <Typography
          variant="h4"
          align="center"
          sx={{ mb: 4, fontWeight: 600, letterSpacing: 1 }}
        >
          Feature Flags
        </Typography>

        <TextField
          fullWidth
          label="Feature Key"
          margin="normal"
          value={featureKey}
          onChange={(e) => setFeatureKey(e.target.value)}
        />

        <FormControlLabel
          control={
            <Checkbox
              checked={enabled}
              onChange={(e) => setEnabled(e.target.checked)}
            />
          }
          label="Enabled"
        />

        <Button variant="contained" onClick={createOrUpdateFeature}>
          {editId ? "Update Feature" : "Create Feature"}
        </Button>
        {editId && (
          <Button
            variant="outlined"
            color="secondary"
            sx={{ ml: 2 }}
            onClick={() => {
              setFeatureKey("");
              setEnabled(false);
              setEditId(null);
            }}
          >
            Cancel
          </Button>
        )}

        <List sx={{ mt: 4, display: "flex", flexDirection: "column", gap: 2 }}>
          {features.map((feature) => (
            <ListItem key={feature._id} disableGutters sx={{ p: 0 }}>
              <Box
                sx={{
                  width: "100%",
                  // background: "#f5f5f5",
                  backgroundColor: "rgb(250, 250, 250)",
                  borderRadius: 2,
                  p: 2,
                  display: "flex",
                  alignItems: "center",
                  gap: 2,
                  // boxShadow: 2,
                }}
              >
                <span style={{ minWidth: 180 }}>
                  {feature.featureKey} -{" "}
                  {feature.enabled ? "Enabled" : "Disabled"}
                </span>
                <div style={{ display: "flex", gap: 8 }}>
                  <Button
                    color="primary"
                    onClick={() => startEdit(feature)}
                    size="small"
                  >
                    Edit
                  </Button>
                  <Button
                    color="error"
                    onClick={() => deleteFeature(feature._id)}
                    size="small"
                  >
                    Delete
                  </Button>
                </div>
              </Box>
            </ListItem>
          ))}
        </List>
      </Paper>
    </Container>
  );
}

export default FeatureDashboard;
