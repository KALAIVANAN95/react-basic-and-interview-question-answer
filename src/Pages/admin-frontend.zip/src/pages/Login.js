import { Button, Container, Paper, TextField, Typography } from "@mui/material";

import { useState } from "react";

import API from "../api/axios";
import { Link } from "react-router-dom";

function Login() {
  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const handleLogin = async () => {
    try {
      const res = await API.post("/auth/login", form);

      localStorage.setItem("token", res.data.token);

      window.location.href = "/dashboard";
    } catch (error) {
      alert("Login Failed");
    }
  };

  return (
    <Container maxWidth="sm">
      <Paper sx={{ p: 4, mt: 5 }}>
        <Typography variant="h4">Admin Login</Typography>

        <TextField
          fullWidth
          label="Email"
          margin="normal"
          onChange={(e) =>
            setForm({
              ...form,
              email: e.target.value,
            })
          }
        />

        <TextField
          fullWidth
          type="password"
          label="Password"
          margin="normal"
          onChange={(e) =>
            setForm({
              ...form,
              password: e.target.value,
            })
          }
        />

        <Button fullWidth variant="contained" onClick={handleLogin}>
          Login
        </Button>
        <Typography align="center" sx={{ mt: 2 }}>
          Don’t have an account?{" "}
          <Link
            to="/signup"
            style={{
              textDecoration: "none",
              color: "#1976d2",
              fontWeight: 500,
            }}
          >
            Sign Up
          </Link>
        </Typography>
      </Paper>
    </Container>
  );
}

export default Login;
