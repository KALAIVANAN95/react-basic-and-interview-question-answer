import {
  Button,
  Container,
  MenuItem,
  Paper,
  TextField,
  Typography,
} from "@mui/material";

import { useEffect, useState } from "react";

import API from "../api/axios";

function Signup() {
  const [organizations, setOrganizations] = useState([]);

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    organizationId: "",
  });

  const fetchOrganizations = async () => {
    try {
      // Fetch organizations from public endpoint, no auth required
      const res = await API.get("/public/organizations");
      setOrganizations(res.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchOrganizations();
  }, []);

  const handleSignup = async () => {
    try {
      await API.post("/auth/signup", form);

      alert("Signup Success");

      window.location.href = "/";
    } catch (error) {
      alert("Signup Failed");
    }
  };

  return (
    <Container maxWidth="sm">
      <Paper sx={{ p: 4, mt: 5 }}>
        <Typography variant="h4">Admin Signup</Typography>

        <TextField
          fullWidth
          label="Name"
          margin="normal"
          onChange={(e) =>
            setForm({
              ...form,
              name: e.target.value,
            })
          }
        />

        <TextField
          fullWidth
          label="Email"
          margin="normal"
          onChange={(e) =>
            setForm({
              ...form,
              email: e.target.value,
            })
          }
        />

        <TextField
          fullWidth
          type="password"
          label="Password"
          margin="normal"
          onChange={(e) =>
            setForm({
              ...form,
              password: e.target.value,
            })
          }
        />

        <TextField
          select
          fullWidth
          label="Organization"
          margin="normal"
          onChange={(e) =>
            setForm({
              ...form,
              organizationId: e.target.value,
            })
          }
        >
          {organizations.map((org) => (
            <MenuItem key={org._id} value={org._id}>
              {org.name}
            </MenuItem>
          ))}
        </TextField>

        <Button fullWidth variant="contained" onClick={handleSignup}>
          Signup
        </Button>
      </Paper>
    </Container>
  );
}

export default Signup;
